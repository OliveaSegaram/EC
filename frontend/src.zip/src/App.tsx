import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { AppRouter } from './routes';
import { AuthProvider } from './provider/AuthProvider';
import { AppContextProvider } from './provider/AppContext';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const App = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContextProvider>
          <AppRouter />
          <ToastContainer position="top-right" autoClose={3000} />
        </AppContextProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
