import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LoginAssets } from '../assets/icons/login/login';
import { useAppContext } from '../provider/AppContext';

const Register = () => {
    const { backendUrl } = useAppContext();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    role: '',
    attachment: null as File | null
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData({ ...formData, attachment: file });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = new FormData();
    Object.entries(formData).forEach(([key, val]) => {
      payload.append(key, val as string | Blob);
    });

    try {
      const response = await fetch(`${backendUrl}/auth/register`, {
        method: 'POST',
        body: payload
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.message || 'Registration failed');
      }

      alert('Registration submitted! Wait for root approval.');
      navigate('/login');
    } catch (err: any) {
      alert(err.message || 'Registration failed');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-white px-4">
      <div className="flex shadow-xl rounded-xl overflow-hidden">
        {/* Left form section */}
        <div className="bg-white p-10 w-96">
          <h2 className="text-center text-2xl font-bold text-gray-800 mb-2">Register</h2>
          <p className="text-center text-gray-500 text-sm mb-6">Create a new account</p>

          <form onSubmit={handleSubmit}>
            <input
              name="username"
              placeholder="Username"
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded-full mb-3"
              required
            />

            <input
              name="email"
              type="email"
              placeholder="Email"
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded-full mb-3"
              required
            />

            <input
              name="password"
              type="password"
              placeholder="Password"
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded-full mb-3"
              required
            />

            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded-full mb-3"
              required
            >
              <option value="">-- Select Role --</option>
              <option value="subject_clerk">Subject Clerk</option>
              <option value="super_user">Super User</option>
              <option value="technical_officer">Technical Officer</option>
              <option value="dc">DC</option>
              <option value="other">Other</option>
            </select>

            <input
              type="file"
              name="attachment"
              onChange={handleFileChange}
              className="mb-3"
              required
            />

            <button
              type="submit"
              className="w-full py-2 rounded-full text-white text-xl bg-gradient-to-b from-purple-600 to-purple-900 shadow-md transition duration-300 hover:shadow-lg"
            >
              Register
            </button>

            <p className="text-center text-sm mt-4">
              Already have an account?{' '}
              <span className="text-purple-700 font-semibold cursor-pointer" onClick={() => navigate('/login')}>
                Login
              </span>
            </p>
          </form>
        </div>

        {/* Right welcome section */}
        <div className="bg-gradient-to-b from-[#8A1FE7] to-[#1C0267] text-white px-10 py-8 w-96 flex flex-col justify-center items-center">
          <img src={LoginAssets.Logo} className="w-16 h-16 mb-3" alt="logo" />
          <p className="text-sm">මැතිවරණ කොමිෂන් සභාව</p>
          <p className="text-sm">தேர்தல் ஆணைக்குழு</p>
          <p className="text-sm mb-2">Election Commission</p>
          <h2 className="text-xl font-bold">Welcome</h2>
          <p className="text-center text-sm mt-1">Election Commission<br />Meeting Management System</p>
        </div>
      </div>
    </div>
  );
};

export default Register;
