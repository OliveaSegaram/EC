import React, { useEffect, useState } from 'react';
import SidebarLayout from '../../components/common/SidebarLayout'; 
import RegistrationPanel from '../../components/root/RegistrationPanel';
import IssuePanel from '../../components/root/IssuePanel';
import RolePanel from '../../components/root/RolePanel';

const RootDashboard = () => {
  const [activeTab, setActiveTab] = useState<'registration' | 'issues' | 'roles' | 'report'>('registration');

  // Handle the tab change based on the hash in the URL
  useEffect(() => {
    const hash = window.location.hash.replace('#', '');
    if (['registration', 'issues', 'roles', 'report'].includes(hash)) {
      setActiveTab(hash as typeof activeTab);
    }
  }, [window.location.hash]);

  // Define the tabs for SidebarLayout
  const tabs = [
    { key: 'registration', label: 'Registration' },
    { key: 'issues', label: 'Issues' },
    { key: 'roles', label: 'Roles' },
    { key: 'report', label: 'Report' },
  ];

  return (
    <SidebarLayout title="SuperAdmin Dashboard" tabs={tabs}>
      <div>
        {activeTab === 'registration' && <RegistrationPanel />}
        {activeTab === 'issues' && <IssuePanel />}
        {activeTab === 'roles' && <RolePanel />}
        {activeTab === 'report' && <div>Report View (to be implemented)</div>}
      </div>
    </SidebarLayout>
  );
};

export default RootDashboard;
