import React from 'react';
const RootDashboard = () => {
  return <div>Welcome Root User</div>;
};
export default RootDashboard;
