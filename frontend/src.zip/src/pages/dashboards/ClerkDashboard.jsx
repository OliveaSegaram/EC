import React from 'react';
const ClerkDashboard = () => {
  return <div>Welcome Subject Clerk</div>;
};
export default ClerkDashboard;
