// src/assets/icons/login/login.ts
import User from './User.svg';
import Padlock from './Padlock.svg';
import Logo from './Logo.png';

export const LoginAssets = {
  User,
  Padlock,
  Logo
};
