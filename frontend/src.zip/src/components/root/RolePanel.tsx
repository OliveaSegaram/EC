// === components/root/RolePanel.tsx ===
import React, { useEffect, useState } from 'react';

interface Role {
  id: number;
  name: string;
}

const RolePanel: React.FC = () => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [newRole, setNewRole] = useState('');

  const fetchRoles = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/roles', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
      const data = await res.json();
      setRoles(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddRole = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:5000/api/roles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ name: newRole }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setNewRole('');
      fetchRoles();
    } catch (err: unknown) {
      if (err instanceof Error) {
        alert(err.message || 'Failed to add role');
      }
    }
  };

  const handleDeleteRole = async (roleId: number) => {
    if (window.confirm('Are you sure you want to delete this role?')) {
      try {
        await fetch(`http://localhost:5000/api/roles/${roleId}`, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        });
        fetchRoles();
      } catch (err) {
        console.error(err);
      }
    }
  };

  useEffect(() => {
    fetchRoles();
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">Role Management</h1>

      <div className="flex space-x-4 mb-6">
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Registrations</button>
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Issues</button>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md">Roles</button>
      </div>

      <form onSubmit={handleAddRole} className="flex gap-2 mb-6">
        <input
          type="text"
          placeholder="New Role"
          value={newRole}
          onChange={(e) => setNewRole(e.target.value)}
          className="border p-2 rounded w-60"
          required
        />
        <button type="submit" className="bg-purple-700 text-white px-4 py-2 rounded">
          Add Role
        </button>
      </form>

      <ul className="bg-white p-4 rounded shadow space-y-2">
        {roles.map((role) => (
          <li key={role.id} className="flex justify-between items-center border-b py-1">
            <span>{role.name}</span>
            <button
              onClick={() => handleDeleteRole(role.id)}
              className="text-red-600 hover:text-red-800"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RolePanel;