// === components/root/IssuePanel.tsx ===
import React from 'react';

const IssuePanel: React.FC = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">Issue Management</h1>

      <div className="flex space-x-4 mb-6">
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Registrations</button>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md">Issues</button>
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Roles</button>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white shadow rounded-lg p-4">
          <p className="text-sm text-gray-500">Total Issues</p>
          <h3 className="text-xl font-bold">12</h3>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <p className="text-sm text-gray-500">Open</p>
          <h3 className="text-xl font-bold">7</h3>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <p className="text-sm text-gray-500">Resolved</p>
          <h3 className="text-xl font-bold">5</h3>
        </div>
      </div>

      <div className="bg-white rounded shadow p-4">
        <p className="text-gray-600">(Issue table or cards go here)</p>
      </div>
    </div>
  );
};

export default IssuePanel;