import React, { useEffect, useState } from 'react';
import { FiEye, FiTrash2 } from 'react-icons/fi';

const RegistrationTab: React.FC = () => {
  const [users, setUsers] = useState<any[]>([]);

  const fetchUsers = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/root/pending-users', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Count stats
  const total = users.length;
  const verified = users.filter((u) => u.isVerified).length;
  const pending = total - verified;

  return (
    <div className="p-4">
      {/* Page Header */}
      <h1 className="text-2xl font-bold mb-6">Super Admin Dashboard</h1>

      {/* Tabs */}
      <div className="flex space-x-4 mb-6">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md">Registrations</button>
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Issues</button>
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Roles</button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white shadow rounded-lg p-4">
          <p className="text-sm text-gray-500">Total Registrations</p>
          <h3 className="text-xl font-bold">{total}</h3>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <p className="text-sm text-gray-500">Pending Verification</p>
          <h3 className="text-xl font-bold">{pending}</h3>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <p className="text-sm text-gray-500">Verified Users</p>
          <h3 className="text-xl font-bold">{verified}</h3>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded shadow overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="bg-gray-200 text-left text-sm text-gray-600">
              <th className="p-3">Name</th>
              <th className="p-3">Email</th>
              <th className="p-3">Role</th>
              <th className="p-3">Attachment</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id} className="border-t hover:bg-gray-50 text-sm">
                <td className="p-3">{user.username}</td>
                <td className="p-3">{user.email}</td>
                <td className="p-3">{user.Role?.name}</td>
                <td className="p-3">
                  {user.attachment ? (
                    <a
                      href={`http://localhost:5000/${user.attachment}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-500 underline"
                    >
                      View
                    </a>
                  ) : (
                    '—'
                  )}
                </td>
                <td className="p-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    user.isVerified
                      ? 'bg-green-100 text-green-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {user.isVerified ? 'Verified' : 'Pending'}
                  </span>
                </td>
                <td className="p-3">
                  <div className="flex space-x-2 text-lg text-gray-600">
                    <button className="hover:text-blue-600" title="View">
                      <FiEye />
                    </button>
                    <button className="hover:text-red-600" title="Delete">
                      <FiTrash2 />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RegistrationTab;
