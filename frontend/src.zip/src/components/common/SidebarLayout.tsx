
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import type { FunctionComponent } from 'react';
import { FiUsers, FiAlertCircle, FiShield, FiBarChart2 } from 'react-icons/fi';

// Define types
type Tab = { key: string; label: string };

type SidebarLayoutProps = {
  title: string;
  tabs: Tab[];
  children: React.ReactNode;
};

// Map icons as components
const iconMap: Record<string, FunctionComponent<{ className?: string }>> = {
  registration: FiUsers,
  issues: FiAlertCircle,
  roles: FiShield,
  report: FiBarChart2,
};

const SidebarLayout: React.FC<SidebarLayoutProps> = ({ tabs, children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const activeTab = location.hash.replace('#', '') || tabs[0].key;

  const handleTabClick = (tabKey: string) => {
    navigate(`${location.pathname}#${tabKey}`);
  };

  return (
    <div className="flex min-h-screen font-sans bg-gray-100">
      <aside className="w-64 bg-white border-r shadow-sm px-6 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-purple-700">Issue Tracker</h1>
        </div>
        <nav className="flex flex-col space-y-3">
          {tabs.map((tab) => {
            const Icon = iconMap[tab.key];
            return (
              <button
                key={tab.key}
                onClick={() => handleTabClick(tab.key)}
                className={`flex items-center px-4 py-2 rounded-md transition-all text-left ${
                  activeTab === tab.key
                    ? 'bg-blue-100 text-blue-700 font-semibold'
                    : 'hover:bg-gray-200 text-gray-700'
                }`}
              >
                <Icon className="inline mr-2" /> {tab.label}
              </button>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 p-8 bg-gray-50 overflow-auto">{children}</main>
    </div>
  );
};

export default SidebarLayout;